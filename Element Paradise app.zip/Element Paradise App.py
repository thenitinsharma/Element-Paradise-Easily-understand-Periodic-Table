from tkinter import*
from tkinter import*
from tkinter import font 
from tkinter.ttk import Progressbar
from tkinter import ttk
from PIL import Image,ImageTk
from KEEpydb import KEEpydb
import tkinter as tk
import p
import pygame
import random
import time
import webbrowser
from tkinter import PhotoImage
import tkinter as tk

# dictionary of colors:
color = {"nero": "#252726", "orange": "#FF8700", "darkorange": "#FE6101"}

win=Tk()


width_of_window = 427
height_of_window = 250
screen_width = win.winfo_screenwidth()
screen_height = win.winfo_screenheight()
x_coordinate = (screen_width/2)-(width_of_window/2)
y_coordinate = (screen_height/2)-(height_of_window/2)
win.geometry("%dx%d+%d+%d" %(width_of_window,height_of_window,x_coordinate,y_coordinate))


win.overrideredirect(1)


s = ttk.Style()
s.theme_use('clam')
s.configure("red.Horizontal.TProgressbar", foreground='red', background='green') #4f4f4f
progress=Progressbar(win,style="red.Horizontal.TProgressbar",orient=HORIZONTAL,length=500,mode='determinate',)

def new_win():

    # setting root window:
    root =Tk()
    root.title("Element Paradise")
    #root.iconbitmap("periodic-table.ico")
    #root.geometry("1395x700+0+0")
    root.state("zoomed")

    
    # loading Navbar icon image:
    navIcon =ImageTk.PhotoImage(Image.open("open.png").resize((30,30),Image.ANTIALIAS))
    closeIcon =ImageTk.PhotoImage(Image.open("close.png").resize((30,30),Image.ANTIALIAS))

    # setting switch function:
    # top Navigation bar:
    topFrame =Frame(root, bg=color["orange"])
    topFrame =Frame(root, bg=color["orange"])
    topFrame.pack(side="top", fill= X)


    # Header label text:
    homeLabel = Label(topFrame, text="Element Paradise", font="Bahnschrift 15", bg=color["orange"], fg="gray17", height=2, padx=20)
    homeLabel.pack(side="right")

    # Main label :

    ##########################################  placing an image  #################################################

    photo=ImageTk.PhotoImage(Image.open("background.jpg").resize((1400,500),Image.ANTIALIAS))

    background_label=Label(root,image=photo)
    background_label.place(x=0,y=200)

    welcome_frame=Frame(root,bg="white",height=200,highlightthickness=5,highlightbackground="Blue",width=1370,cursor="hand2").place(x=0,y=45)
    welcome=ImageTk.PhotoImage(Image.open("intro1.png").resize((1356,110),Image.ANTIALIAS))
    banner_label=Label(welcome_frame,image=welcome)
    banner_label.place(x=5,y=51)

    ####################################### window for searching element ################################################

    def searchbyname():
        """This Function is used to Create Window for Search Element By Element Name """
        top=Toplevel()
        top.geometry("800x500")
        top.iconbitmap("periodic-table.ico")
        fr=Frame(top,bg="white",height=500,width=800).pack()
        Label(top,text="Search Element to get its information",fg="White",bg="blue",font="Forte 18 bold",padx=200,pady=10).place(x=0,y=0)
        Label(top,text=" Search🔎Using Atomic Number ",fg="Blue",bg="white",font=" verdana 18 bold",padx=200,pady=10).place(x=0,y=50)
        ExampleEntry=StringVar()
        ExampleEntry.set("Enter Element Name")
        entry=Entry(top,textvariable=ExampleEntry,bg='White',highlightthickness=5,highlightbackground="Blue",highlightcolor="green",width=50,font=("cascadiacode  12 bold")).place(x=100,y=150,height=50)
        name_var=StringVar()
        def submit():
            name=ExampleEntry.get()
            print("The Atomic Number:",name)
        #print(search_query)
        '''
        def click():
            q=KEEpydb.query('ElementInfo','NitinKumar','123456')
            d=q.get_all()
            for i in d:
                if i[0]==search_query:
                    #print(i)
                 return i
        g=click()'''
        #search_output=Label(top,text=g,font="verdana")
        #search_output.place(x=200,y=250)

            #print("The Element Name:",name)
        def destroy():
            dist=top.destroy()
        Back=Button(top,text='Back ⪻',fg='Purple',borderwidth=5,command=lambda:[destroy(),search()],bg='white',font='verdana 18 bold',padx=18).place(x=50,y=400)
        sub=Button(top,text="Submit",command=submit,bg='white',fg='Blue',font='verdana 18 bold',padx=18).place(x=600,y=150)
        #top.mainloop()
        
        #print(d)
        #e=int(input("enter element name "))
        

    def searchbynumber():
        """This Function is used to Create Window for Search Element By Element Atmic Number """
        top1=Toplevel()
        top1.geometry("800x500")
        top1.iconbitmap("periodic-table.ico")
        fr=Frame(top1,bg="white",height=500,width=800).pack()
        Label(top1,text="Search Element to get its information",fg="White",bg="blue",font="Forte 18 bold",padx=200,pady=10).place(x=0,y=0)
        Label(top1,text=" Search🔎Using Atomic Number ",fg="Blue",bg="white",font=" verdana 18 bold",padx=200,pady=10).place(x=0,y=50)

        ExampleEntry=StringVar()
        ExampleEntry.set("Enter atomic number")
        entry=Entry(top1,bg='White',highlightthickness=5,highlightbackground="Blue",highlightcolor="green",textvariable=ExampleEntry,width=50,font=("cascadiacode 12 bold")).place(x=100,y=150,height=50)
        def submit():
            atomic_number=ExampleEntry.get()
            print("The Atomic Number:",atomic_number)
        def destroy():
            dist=top1.destroy()
        Back=Button(top1,text='Back ⪻',fg='Purple',borderwidth=5,command=lambda:[destroy(),search()],bg='white',font='verdana 18 bold',padx=18).place(x=50,y=400)
        sub=Button(top1,text="Submit",command=submit,bg='white',fg='Blue',font='verdana 18 bold',padx=18).place(x=600,y=150)
    ####################################### Main window of Searching Element Info ######################################


    def search():
        """This function is used to create Window for Searching element Information"""
        search_root=Tk()
        search_root.geometry("800x500")
        search_root.title("Element Paradise")
        search_root.iconbitmap("periodic-table.ico")

        
        def destroy():
            w=search_root.destroy()
        def callback(url):
            webbrowser.open_new_tab(url)

        Label(search_root,text="Search Element to get its information",fg="White",bg="blue",font="Forte 18 bold",padx=200,pady=10).place(x=0,y=0)
        link=Label(search_root,text="For More Information about Periodic Table Click Here",fg="purple",font="Arial 13 bold")
        link.bind("<Button-1>",lambda e:
        callback("https://en.wikipedia.org/wiki/Periodic_table"))
        link.place (x=350,y=450)
        Button(search_root,text='Search using Element Name 🔎',borderwidth=5,font="verdana 18 bold",fg="blue",command=lambda:[destroy(),searchbyname()],cursor="hand2",bg="white",padx=10,pady=10).place(x=100,y=100)
        
        Button(search_root,text='Search using Atomic Number 🔎',borderwidth=5,font="verdana 18 bold",fg="blue",command=lambda:[destroy(),searchbynumber()],cursor="hand2",bg="white",padx=10,pady=10).place(x=100,y=200)

        Button(search_root,text='Back ⪻',fg='Purple',borderwidth=5,bg='white',command=destroy,font='verdana 18 bold',padx=18).place(x=50,y=400)

    def about():
        """This function is used to create about window of Element Paradise App"""
        root=Tk()
        root.iconbitmap("periodic-table.ico")
        root.geometry("1400x700+0+0")
        root.title("about")
        root.configure(bg='white')
        #root.minsize(400,400)
        #root.maxsize(1400,700)
        def back():
            w=root.destroy()


        label=Label(root,text="About Element Paradise App",fg="White",bg="blue",font="Verdana 20 bold",padx=550,pady=10,anchor=CENTER)
        label.grid(row=0,column=0,columnspan=20)
        text_label=Label(root,text='''Element Paradise App is made to help student 
        so that they can better understand 
        chemistry by learning element
        information and remember it to become 
        asset in the modern era of science
        And we our creating app for making 
        education or learning chemistry and science easier.....''',fg="white",bg='blue',font="forte 30 bold")
        text_label.place(x=200,y=150)
        creator=Label(root,text='Created By-: ',fg='blue',bg='white',font="arial 18 bold")
        creator.place(x=850,y=600)
        name=Label(root,text='Nitin Kumar Sharma',bg='white',font='verdana 18 bold',fg='purple')
        name.place(x=1000,y=600)
        Button(root,text='Back ⪻',borderwidth=5,command=lambda:[back(),root()],font='verdana 12 bold',padx=18,bg='white',fg='blue').place(x=50,y=600)

    ############################################## History of Periodic Table ##################################################
    def history():
        his=Toplevel()
        his.geometry("800x500")
        his.iconbitmap("periodic-table.ico")
        Label(his,text="History of Periodic Table ",fg="White",bg="blue",font="Forte 18 bold",padx=200,pady=10).place(x=0,y=0)


    



    open_button=Button(text='Open Periodic table',borderwidth=5,font="verdana 18 bold",command=p.main,cursor="hand2",fg="blue",bg="white",padx=10,pady=10)
    open_button.place(x=100,y=460)


    search_button=Button(text='Search element',borderwidth=5,font="verdana 18 bold",fg="blue",command=search,cursor="hand2",bg="white",padx=10,pady=10)
    search_button.place(x=100,y=300)


    Button(text='Play Trick song',font="verdana 18 bold",borderwidth=5,fg="blue",cursor="hand2",command=lambda:play("Trick song.mp3"),bg="white",padx=10,pady=10).place(x=100,y=380)

    history_button=Button(text="History of Periodic Table",borderwidth=5,font="verdana 18 bold",fg="blue",cursor="hand2",padx=10,pady=10)
    history_button.place(x=100,y=540)



    def toggle_win():
        f1=Frame(root,width=300,height=700,bg='#12c4c0')
        f1.place(x=0,y=0)
        


        #buttons
        def bttn(x,y,text,bcolor,fcolor,cmd):
        
            def on_entera(e):
                myButton1['background'] = bcolor #ffcc66
                myButton1['foreground']= '#262626'  #000d33

            def on_leavea(e):
                myButton1['background'] = fcolor
                myButton1['foreground']= '#262626'

            myButton1 = Button(f1,text=text,
                        width=42,
                        height=2,
                        fg='#262626',
                        border=0,
                        bg=fcolor,
                        activeforeground='#262626',
                        activebackground=bcolor,            
                            command=cmd)
                        
            myButton1.bind("<Enter>", on_entera)
            myButton1.bind("<Leave>", on_leavea)

            myButton1.place(x=x,y=y)

        bttn(0,80,'A B O U T','#0f9d9a','#12c4c0',about)
        bttn(0,117,'C O N T A C T  U S','#0f9d9a','#12c4c0',None)
        bttn(0,154,'F E E D B A C K','#0f9d9a','#12c4c0',None)
        bttn(0,191,'H E L P','#0f9d9a','#12c4c0',None)
        #bttn(0,228,'A C E R','#0f9d9a','#12c4c0',None)
        #bttn(0,265,'A C E R','#0f9d9a','#12c4c0',None)
        
        def dele():
            f1.destroy()

        global img2
        img2 = ImageTk.PhotoImage(Image.open("close.png"))

        Button(f1,
            image=img2,
            border=0,
            command=dele,
            bg='#12c4c0',
            activebackground='#12c4c0').place(x=5,y=10)
        


    # Navbar button:
    navbarBtn =Button(topFrame, image=navIcon, bg=color["orange"], activebackground=color["orange"], bd=0, padx=20, command=toggle_win)
    navbarBtn.place(x=10, y=10)

    #########################################  defining animation  #################################################
    colors=['red','green','blue','purple']
    def color_changer():
        fg=random.choice(colors)
        label.config(fg=fg)
        label.after(700,color_changer)
        labels=['Created by👉- 👨Nitin Kumar Sharma','Hey 😎🤗(❁´◡`❁) You are using Element Paradise']
        text=random.choice(labels)
        label.config(text=text)
    label=Label(root,font=('Forte',20,'bold'),bg="white")
    label.place(x=500,y=155)
    color_changer()

    title2_label=Label(text="Class-12 PCM A1  📚  Roll no.-31",fg="red",font="verdana 18 bold",bg="white")
    title2_label.place(x=550,y=195)

    root.mainloop()
    ################################################# code for playing song  ###########################################
    
    
pygame.init()
_playing=False
def play(path):
    global _playing
    if _playing==False:
        _playing=True
        pygame.mixer.music.load(path)
        pygame.mixer.music.play(1)
    else:
        pygame.mixer.music.pause()
        _playing=False


# window in mainlo
def bar():

    l4=Label(win,text='Loading...',fg='white',bg=a)
    lst4=('Calibri (Body)',10)
    l4.config(font=lst4)
    l4.place(x=18,y=210)
    
    r=0
    for i in range(100):
        progress['value']=r
        win.update_idletasks()
        time.sleep(0.03)
        r=r+1
    
    win.destroy()
    new_win()
        
    
progress.place(x=-10,y=235)




#############
# frame 333333333333333333333333
#
###########


a='#249794'#BLUE COLOR
Frame(win,width=427,height=241,bg=a).place(x=0,y=0)  #249794
b1=Button(win,width=10,height=1,text='Get Started',command=bar,border=0,fg=a,bg='white')
b1.place(x=170,y=200)


###################################################  Label of Splash Window #############################################################

l1=Label(win,text='ELEMENT',fg='white',bg=a)
lst1=('Calibri (Body)',18,'bold')
l1.config(font=lst1)
l1.place(x=50,y=80)

l2=Label(win,text='PARADISE',fg='white',bg=a)
lst2=('Calibri (Body)',18)
l2.config(font=lst2)
l2.place(x=175,y=82)

l3=Label(win,text='LEARNING MADE EASY',fg='white',bg=a)
lst3=('Calibri (Body)',13)
l3.config(font=lst3)
l3.place(x=50,y=110)

  


win.mainloop()

############################################## Thanks For Using ###################################################